<?php
namespace LBHurtado\OMRTemplates\Renderers;

class MultipleChoiceRenderer {
    public function render($pdf, array $section): void {
        // Render multiple-choice section stub
    }
}

<?php
namespace LBHurtado\OMRTemplates\Engine;

use TCPDF;

class SmartLayoutRenderer {
    public function render(array $compiled): array {
        $pdf = new TCPDF();
        $pdf->AddPage();
        $pdf->SetFont('Helvetica', '', 12);
        $pdf->MultiCell(0, 10, $compiled['document']['title'] ?? 'Untitled Document', 0, 'L');
        $path = sys_get_temp_dir() . '/sample.pdf';
        $pdf->Output($path, 'F');
        return ['pdf' => $path];
    }
}

# Automatic Ballot & Survey Layout Engine for `lbhurtado/omr-templates`
(Full markdown content from the assistant's previous message would go here.)
